## 1.6.2 (2022-08-09)


### Bug Fixes

* **deps:** update dependency @wppconnect-team/wppconnect to ^1.16.1 ([#866](https://github.com/wppconnect-team/wppconnect-server/issues/866)) ([a824339](https://github.com/wppconnect-team/wppconnect-server/commit/a8243392f8daadef5dec2205263d5a44840ae4ef))



## 1.6.1 (2022-08-05)


### Bug Fixes

* **deps:** update dependency @wppconnect-team/wppconnect to ^1.16.0 ([#860](https://github.com/wppconnect-team/wppconnect-server/issues/860)) ([5f72973](https://github.com/wppconnect-team/wppconnect-server/commit/5f72973788d2844d2297acd73b96e76001b70c37))



# 1.6.0 (2022-07-20)



# 1.5.0 (2022-07-12)


### Features

* Delete all chats close [#483](https://github.com/wppconnect-team/wppconnect-server/issues/483) ([f47a253](https://github.com/wppconnect-team/wppconnect-server/commit/f47a253b1024778f9c3ed5d14a638689be464936))



# 1.4.0 (2022-06-29)



## 1.3.4 (2022-06-20)



## 1.3.3 (2022-06-01)



## 1.3.2 (2022-05-31)



## 1.3.1 (2022-05-10)



# 1.3.0 (2022-05-10)


### Features

* Updated all packages ([5e7b9f2](https://github.com/wppconnect-team/wppconnect-server/commit/5e7b9f2240ccc0e44a129296e92dd6fb5393380e))



# 1.2.0 (2022-04-25)



## 1.1.23 (2022-03-13)



## 1.1.22 (2022-03-07)



## 1.1.21 (2022-02-24)



## 1.1.20 (2022-01-23)



## 1.1.19 (2022-01-21)



## 1.1.18 (2022-01-17)



## 1.1.17 (2022-01-16)



## 1.1.16 (2022-01-14)



## 1.1.15 (2022-01-09)



## 1.1.14 (2021-12-21)



## 1.1.13 (2021-12-09)



## 1.1.12 (2021-12-09)



## 1.1.11 (2021-11-16)



## 1.1.10 (2021-11-12)



## 1.1.9 (2021-11-08)



## 1.1.8 (2021-11-08)



## 1.1.7 (2021-10-21)



## 1.1.6 (2021-10-13)


### Bug Fixes

* block/unblock contato. ([9401b16](https://github.com/wppconnect-team/wppconnect-server/commit/9401b168ce08eb62c5ea392db82df34b69753775))



## 1.1.5 (2021-10-01)



## 1.1.4 (2021-09-22)



## 1.1.3 (2021-08-13)



## 1.1.2 (2021-08-11)



## 1.1.1 (2021-08-06)



# 1.1.0 (2021-08-04)



## 1.0.3 (2021-07-15)

## 1.0.2 (2021-07-14)

## [1.0.1](https://github.com/wppconnect-team/wppconnect-server/compare/v1.0.0...v1.0.1) (2021-06-13)

### Bug Fixes

- Archive only unarchived chats ([#37](https://github.com/wppconnect-team/wppconnect-server/issues/37)) ([5985296](https://github.com/wppconnect-team/wppconnect-server/commit/5985296d97a9ccb19625e7ddbc07ecacc0ce65c6))
- Corrigido a entrada principal de arquivo JS ([f513c64](https://github.com/wppconnect-team/wppconnect-server/commit/f513c64247fe01e9297df27036ad1141278e87c2))
